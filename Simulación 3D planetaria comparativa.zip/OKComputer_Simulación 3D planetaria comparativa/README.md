# Sistema Solar 3D - Simulación Interactiva

Una aplicación web interactiva que simula el sistema solar en 3D, inspirada en el sistema de visualización de la NASA. Permite explorar planetas, comparar física entre diferentes mundos y aprender sobre astronomía.

## Características

### 🌍 Simulación 3D del Sistema Solar
- Modelo 3D completo de todos los planetas y satélites principales
- Órbitas realistas y rotaciones planetarias
- Control de tiempo y velocidad de simulación
- Vista interactiva con navegación por planetas

### ⚖️ Comparación de Física Planetaria
- Compara gravedad, temperatura y velocidad de escape entre planetas
- Simulación de caída de objetos en diferentes mundos
- Objetos interactivos: astronautas, cohetes, rovers, satélites
- Visualización en tiempo real del comportamiento físico

### 📚 Información Educativa
- Historia y características de cada planeta
- Datos científicos actualizados
- Misiones espaciales reales
- Galería de imágenes del sistema solar

### 🎮 Controles Interactivos
- Navegación con mouse y teclado
- Controles de velocidad de tiempo
- Selección de planetas y objetos
- Modo de pantalla completa

## Tecnologías Utilizadas

- **Three.js**: Renderizado 3D y animaciones
- **HTML5 Canvas**: Gráficos y simulaciones
- **CSS3**: Efectos visuales y diseño responsivo
- **JavaScript ES6+**: Lógica de la aplicación
- **WebGL**: Aceleración por hardware

## Estructura del Proyecto

```
/
├── index.html              # Página principal
├── styles.css              # Estilos y diseño
├── js/
│   ├── main.js             # Controlador principal
│   ├── solarSystem.js      # Simulación del sistema solar
│   └── physicsComparison.js # Comparación de física
├── README.md               # Documentación
└── resources/              # Recursos multimedia
```

## Cómo Usar

### Controles del Teclado
- **Espacio**: Pausar/Reanudar simulación
- **R**: Reiniciar vista de cámara
- **F**: Activar/Desactivar pantalla completa
- **M**: Silenciar/Activar audio
- **↑/↓**: Ajustar velocidad de tiempo
- **1-9**: Seleccionar planetas (1=Mercurio, 2=Venus, etc.)

### Controles del Mouse
- **Click**: Seleccionar planetas
- **Scroll**: Zoom en la simulación
- **Arrastrar**: Rotar vista (cuando está disponible)

### Navegación
- Usa la barra de navegación superior para cambiar entre secciones
- La navegación por scroll también está disponible
- Cada sección tiene contenido específico y controles

## Datos Planetarios

La aplicación incluye datos precisos de:

- **Gravedad superficial** (m/s²)
- **Temperatura promedio** (°C)
- **Velocidad de escape** (km/s)
- **Composición atmosférica**
- **Período orbital y de rotación**
- **Número de lunas**

## Objetos Interactivos

### Astronauta
- Simula el comportamiento de un ser humano en diferentes gravedades
- Muestra altura de salto y velocidad de caída

### Cohete
- Calcula requisitos de velocidad de escape
- Muestra diferencias en requisitos de combustible

### Rover
- Simula tracción y movilidad en diferentes superficies
- Muestra limitaciones de operación

### Satélite
- Calcula velocidades orbitales requeridas
- Muestra diferencias en órbitas estables

## Características Técnicas

### Rendimiento
- Optimizado para 60 FPS
- Carga progresiva de recursos
- Gestión eficiente de memoria
- Compatible con dispositivos móviles

### Accesibilidad
- Diseño responsivo
- Controles de teclado
- Alto contraste para mejor legibilidad
- Indicadores visuales claros

### Compatibilidad
- Navegadores modernos (Chrome, Firefox, Safari, Edge)
- Requiere WebGL
- Compatible con dispositivos táctiles

## Instalación y Uso

1. **Clonar o descargar** el proyecto
2. **Abrir** `index.html` en un navegador web moderno
3. **Esperar** a que se carguen los recursos
4. **Explorar** el sistema solar interactivo

No requiere instalación de dependencias adicionales.

## Educación y Ciencia

Esta aplicación está diseñada para:

- **Estudiantes**: Aprender astronomía de manera interactiva
- **Educadores**: Herramienta de enseñanza visual
- **Entusiastas**: Explorar el sistema solar
- **Científicos**: Visualizar datos planetarios

Los datos utilizados son basados en mediciones reales de:
- NASA (National Aeronautics and Space Administration)
- ESA (European Space Agency)
- Datos públicos de misiones espaciales

## Futuras Mejoras

- [ ] Añadir más satélites naturales
- [ ] Incluir asteroides y cometas
- [ ] Simulación de clima planetario
- [ ] Modo multijugador educativo
- [ ] Realidad virtual (VR)
- [ ] Modo offline

## Licencia

Este proyecto es de código abierto para fines educativos.

## Agradecimientos

- Inspirado en el sistema de visualización de NASA Eyes
- Datos proporcionados por NASA y ESA
- Gráficos y animaciones con Three.js
- Comunidad open source por las herramientas utilizadas

---

**Explora el cosmos desde tu navegador web!** 🚀✨